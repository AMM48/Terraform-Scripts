import boto3, os

from_email = os.environ['SENDER_EMAIL']

client = boto3.client('ses')

def event_handler(event, context):
    
    client.send_email (
    Source = from_email,
    Destination={'ToAddresses': [event['Input']['email']]},
    Message={
        'Subject': {'Data': "Whiskers commands you to attend!!!"},
        'Body': {
            'Text': {'Data': event['Input']['message']}
        }
    }
    )
    return "Success!!!"